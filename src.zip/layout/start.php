




<div class="subscribe" >
       
       <div class="container " style="width: 84%;  ">
      
       <div  id="myCarousel" class="carousel slide" data-bs-ride="carousel">
       <!-- Indicators -->
 
     
       <!-- Slides -->
       <div class="carousel-inner" style="border-radius: 20px !important;">
         <div class="carousel-item active">
           <img src="assets/images/slide-img-114-1-1.png" class="d-block w-100 img-fluid" alt="Slide 1">
         </div>
         <div class="carousel-item">
           <img src="assets/images/slide-img-116-1-1.png" class="d-block w-100 img-fluid" alt="Slide 2">
         </div>
         <div class="carousel-item">
           <img src="assets/images/slide-img-119-1-1.png" class="d-block w-100 img-fluid" alt="Slide 3">
         </div>
         <div class="carousel-item">
           <img src="assets/images/slide-img-128-1-1.png" class="d-block w-100 img-fluid" alt="Slide 4">
         </div>
         <!-- Add more slides as needed -->
       </div>
     
       <!-- Controls -->
       <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
         <span style="color: #000000;" class="fa-solid fa-forward fa-rotate-180 fa-2xl" aria-hidden="true"></span>
         <span class="visually-hidden">Previous</span>
       </button>
       <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
         <span  style="color: #000000;" class="fa-solid fa-forward fa-2xl" aria-hidden="true"></span>
         <span class="visually-hidden">Next</span>
       </button>
     
       
     </div>
        </div>
          </div>